#!/bin/bash

cd /home/user
node app.js
